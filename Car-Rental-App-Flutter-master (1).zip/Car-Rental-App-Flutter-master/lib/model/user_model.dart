class User {
  final String uid;
  final String? email;
  final bool? emailVerifed;
  User(this.uid, this.email, this.emailVerifed);
}

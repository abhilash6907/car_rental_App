package com.sobgog.car_rental

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
